<?php
/**
* Plugin Name: First Gutenberg Plugin 
* Description: This is my first gutenberg block plugin
* Version: 1.0
* Author: Sheryar
* Author URI: example.com
*/


if( ! defined( 'ABSPATH' ) ) exit;



class myFirstGutenbergPlugin {

    function __construct(){
        add_action ('init', array($this, 'adminAssets'));
    }

    function adminAssets(){
        wp_register_script('ournewblocktype', plugin_dir_url(__FILE__) . 'build/index.js', array('wp-blocks', 'wp-element'));
        register_block_type('ourplugin/my-first-gurtenberg-plugin', array(
            'editor_script' => 'ournewblocktype',
            'render_callback' => array($this, 'theHTML')
        ));
    }

    function theHTML($attributes){
        ob_start(); ?>

        <h1>Today sky is <?php echo $attributes['skyColor'] ?>. And grass is <?php echo $attributes['grassColor'] ?>!!!</h1>

        <?php return ob_get_clean();
    }


}

$myFirstGutenbergPlugin = new myFirstGutenbergPlugin();