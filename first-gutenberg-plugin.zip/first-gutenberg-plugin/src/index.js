wp.blocks.registerBlockType("ourplugin/my-first-gurtenberg-plugin", {
    title: "My First Gutenberg Block",
    icon: "smiley",
    category: "common",
    attributes: {
        skyColor: {type: "string"},
        grassColor: {type: "string"}
    },
    edit: function(props){

        function updateSkyColor(event){
            props.setAttributes({skyColor: event.target.value})
        }

        function updategrassColor(event){
            props.setAttributes({grassColor: event.target.value})
        }

        return (
            <div>
                <input type="text" placeholder="sky color" value={props.attributes.skyColor} onChange={updateSkyColor} />
                <input type="text" placeholder="grass color" value={props.attributes.grassColor} onChange={updategrassColor} />
            </div>
        )
    },
    save: function(props){
        return null
    }
})